#!/bin/bash
echo "please enter an Input"
read name
clear
echo "my name is $name"
