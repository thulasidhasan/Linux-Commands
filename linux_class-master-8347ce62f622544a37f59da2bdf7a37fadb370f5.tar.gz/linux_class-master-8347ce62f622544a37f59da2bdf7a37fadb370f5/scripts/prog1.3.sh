#!/bin/bash
echo "the File Name: $0" 
echo "the first argument is: $1"
echo "the second argument is: $2"
echo "the third argument is: $3"
echo "the total arguments are: $#"
