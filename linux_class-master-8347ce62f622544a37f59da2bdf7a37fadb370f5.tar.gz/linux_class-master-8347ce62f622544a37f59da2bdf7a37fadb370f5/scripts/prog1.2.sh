#!/bin/bash
read -p "Please enter the text: " name
clear
echo -e "\t\tmy name is \n\n\n\t\t$name"
