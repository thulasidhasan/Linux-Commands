#!/bin/bash
echo "My file name is: $0"
echo "Total CLI ARG are: $#"
echo "$1"
echo "$2"
echo "$3"
