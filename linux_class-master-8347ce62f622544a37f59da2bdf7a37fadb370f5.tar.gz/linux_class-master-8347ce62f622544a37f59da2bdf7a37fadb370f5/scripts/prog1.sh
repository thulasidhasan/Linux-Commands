#!/bin/bash
echo "welcome to the Shell scripting"
echo "DATE: `date "+%Y/%m/%d %H:%M:%S"`"
echo "Author: Gowri"
read -p "Taking Contact Number: " contact
echo "Contact Number is: $contact"
